create view rtpv2measuresall as
select `joomladb`.`rtpv2measure`.`MeasureId`                        AS `MeasureId`,
       `joomladb`.`rtpv2measure`.`MeasureName`                      AS `MeasureName`,
       `joomladb`.`rtpv2measure`.`MeasureDescription`               AS `MeasureDescription`,
       `joomladb`.`rtpv2measure`.`MeasureCategoryId`                AS `MeasureCategoryId`,
       `joomladb`.`rtpv2measure`.`MeasureGoalTypeId`                AS `MeasureGoalTypeId`,
       `joomladb`.`rtpv2measure`.`MeasureGoalDaysPerWeekDefault`    AS `MeasureGoalDaysPerWeekDefault`,
       `joomladb`.`rtpv2measure`.`MeasureOrder`                     AS `MeasureOrder`,
       `joomladb`.`rtpv2measuremusthavemmd`.`MMHMMDMeasureId`       AS `MMHMMDMeasureId`,
       `joomladb`.`rtpv2measuremusthavemmd`.`MMHMMDMMDId`           AS `MMHMMDMMDId`,
       `joomladb`.`rtpv2metricmetadata`.`MetricMetaDataId`          AS `MetricMetaDataId`,
       `joomladb`.`rtpv2metricmetadata`.`MMDName`                   AS `MMDName`,
       `joomladb`.`rtpv2metricmetadata`.`MMDDescription`            AS `MMDDescription`,
       `joomladb`.`rtpv2metricmetadata`.`MMDNormalMin`              AS `MMDNormalMin`,
       `joomladb`.`rtpv2metricmetadata`.`MMDNormalMax`              AS `MMDNormalMax`,
       `joomladb`.`rtpv2metricmetadata`.`MMDAcceptableMin`          AS `MMDAcceptableMin`,
       `joomladb`.`rtpv2metricmetadata`.`MMDAcceptableMax`          AS `MMDAcceptableMax`,
       `joomladb`.`rtpv2metricmetadata`.`MMDSortKey`                AS `MMDSortKey`,
       `joomladb`.`rtpv2metricmetadata`.`MMDMetricSubrangeKey`      AS `MMDMetricSubrangeKey`,
       `joomladb`.`rtpv2mmdcanhavemetric`.`MMDCHMetricId`           AS `MMDCHMetricId`,
       `joomladb`.`rtpv2mmdcanhavemetric`.`MMDCHMMMDId`             AS `MMDCHMMMDId`,
       `joomladb`.`rtpv2mmdcanhavemetric`.`MMDCHMMetricDefault`     AS `MMDCHMMetricDefault`,
       `joomladb`.`rtpv2mmdcanhavemetric`.`MMDCHMDeleted`           AS `MMDCHMDeleted`,
       `joomladb`.`rtpv2metric`.`MetricId`                          AS `MetricId`,
       `joomladb`.`rtpv2metric`.`MetricUnits`                       AS `MetricUnits`,
       `joomladb`.`rtpv2metric`.`MetricDeleted`                     AS `MetricDeleted`,
       `joomladb`.`rtpv2mmdcanhavetimeperiod`.`MMDCHTPTimePeriodId` AS `MMDCHTPTimePeriodId`,
       `joomladb`.`rtpv2mmdcanhavetimeperiod`.`MMDCHTPMMDId`        AS `MMDCHTPMMDId`,
       `joomladb`.`rtpv2mmdcanhavetimeperiod`.`MMDCHTPDefault`      AS `MMDCHTPDefault`,
       `joomladb`.`rtpv2mmdcanhavetimeperiod`.`MMDCHTPDeleted`      AS `MMDCHTPDeleted`,
       `joomladb`.`rtpv2timeperiod`.`TimePeriodId`                  AS `TimePeriodId`,
       `joomladb`.`rtpv2timeperiod`.`TimePeriodPerWhat`             AS `TimePeriodPerWhat`,
       `joomladb`.`rtpv2timeperiod`.`TimePeriodDefault`             AS `TimePeriodDefault`,
       `joomladb`.`rtpv2timeperiod`.`TimePeriodDeleted`             AS `TimePeriodDeleted`
from ((((((`joomladb`.`rtpv2measure` join `joomladb`.`rtpv2measuremusthavemmd`
           on ((`joomladb`.`rtpv2measure`.`MeasureId` =
                `joomladb`.`rtpv2measuremusthavemmd`.`MMHMMDMeasureId`))) join `joomladb`.`rtpv2metricmetadata`
          on ((`joomladb`.`rtpv2measuremusthavemmd`.`MMHMMDMMDId` =
               `joomladb`.`rtpv2metricmetadata`.`MetricMetaDataId`))) join `joomladb`.`rtpv2mmdcanhavemetric`
         on ((`joomladb`.`rtpv2metricmetadata`.`MetricMetaDataId` =
              `joomladb`.`rtpv2mmdcanhavemetric`.`MMDCHMMMDId`))) join `joomladb`.`rtpv2metric`
        on ((`joomladb`.`rtpv2mmdcanhavemetric`.`MMDCHMetricId` =
             `joomladb`.`rtpv2metric`.`MetricId`))) join `joomladb`.`rtpv2mmdcanhavetimeperiod`
       on ((`joomladb`.`rtpv2metricmetadata`.`MetricMetaDataId` =
            `joomladb`.`rtpv2mmdcanhavetimeperiod`.`MMDCHTPMMDId`))) join `joomladb`.`rtpv2timeperiod`
      on ((`joomladb`.`rtpv2mmdcanhavetimeperiod`.`MMDCHTPTimePeriodId` =
           `joomladb`.`rtpv2timeperiod`.`TimePeriodId`)));

